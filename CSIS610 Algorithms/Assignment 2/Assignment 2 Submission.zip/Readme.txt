Each of the problem set for Assignment 1 and Assignment 2 are presented as Public Java Classes. The source code was written JDK 8.0 version.

PascalTriagle class will take an input from the user for depth and outputs a pascal triangle

Inversion class reads from text file placed in the src folder named IntegerArray, and prints Long number of inversion in the data.